from sqlalchemy import Column, Integer, String
from database import Base

# table user
class User(Base):
    table = "users"  # Nom de la table

    id = Column(Integer, primary_key=True, index=True)  # ID unique
    numero = Column(String, unique=True, index=True)    # Numéro de téléphone
    email = Column(String, unique=True, index=True)     # Email
    nom_complet = Column(String)                        # Nom complet
    mot_de_passe = Column(String)                       # Mot de passe (hashé)
