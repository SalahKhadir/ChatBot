from passlib.context import CryptContext
from jose import jwt
from datetime import datetime, timedelta

# Utilisé pour hasher les mots de passe
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Clé secrète pour signer les tokens
SECRET_KEY = "secret"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Vérifie si le mot de passe tapé correspond au hash
def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

# Transforme un mot de passe normal en mot de passe sécurisé
def hash_password(password):
    return pwd_context.hash(password)

# Crée un token JWT avec expiration
def create_token(data: dict):
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    data.update({"exp": expire})  # Ajoute une date d'expiration
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)  # Encode le token
