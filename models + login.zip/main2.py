from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal, engine, Base
from models import User
from schema import UserLogin
from Auth import verify_password, hash_password, create_token

# Crée la table dans la base si elle n'existe pas encore
Base.metadata.create_all(bind=engine)

# Crée l'app FastAPI (notre serveur)
app = FastAPI()


# Fonction pour obtenir une session de base de données
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()  # Ferme la connexion après utilisation

# Route pour se connecter
@app.post("/login")
def login(data: UserLogin, db: Session = Depends(get_db)):
    # Cherche l'utilisateur avec l'email donné
    user = db.query(User).filter(User.email == data.email).first()

    # Vérifie que l'utilisateur existe et que le mot de passe est correct
    if not user or not verify_password(data.mot_de_passe, user.mot_de_passe):
        raise HTTPException(status_code=401, detail="Identifiants invalides")

    # Crée un token JWT avec l'email
    token = create_token({"sub": user.email})
    return {"access_token": token, "token_type": "bearer"}


# Route pour se déconnecter (symbolique ici)
@app.post("/logout")
def logout():
    return {"message": "Déconnexion réussie (le client doit supprimer le token lui-même)"}
