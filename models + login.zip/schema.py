from pydantic import BaseModel

# schéma de connexion
class UserLogin(BaseModel):
    email: str
    mot_de_passe: str


