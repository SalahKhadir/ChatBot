from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Chemin vers la base de données SQLite
DATABASE_URL = "sqlite:///./chatbot.db"

# Crée une "engine" pour comparer avec la base de données
engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}
)

# Crée une session (comme un tunnel) pour interagir avec la base
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

# Base est la classe de base pour tous nos modèles
Base = declarative_base()
